@echo off
setlocal
cd /d "%~dp0"
py -3 -m venv .venv
if errorlevel 1 exit /b 1
.venv\Scripts\python.exe -m pip install -r requirements.txt PyInstaller==6.15.0
if errorlevel 1 exit /b 1
.venv\Scripts\python.exe -m unittest discover -s tests -v
if errorlevel 1 exit /b 1
.venv\Scripts\python.exe -m PyInstaller --noconfirm --clean --onefile --windowed --name MonoIcons --collect-submodules pystray --hidden-import win32timezone main.py
if errorlevel 1 exit /b 1
echo Ready: dist\MonoIcons.exe
