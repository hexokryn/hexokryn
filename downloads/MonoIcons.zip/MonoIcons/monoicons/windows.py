"""Windows shell integration. Does not edit executables or system resources."""
import ctypes
from ctypes import wintypes
import os
from pathlib import Path
import sys

from PIL import Image
import win32com.client
import win32con
import win32gui
import win32ui

from .core import grayscale


def roots():
    shell = win32com.client.Dispatch('WScript.Shell')
    folders = [Path(shell.SpecialFolders(name)) for name in
               ('Desktop', 'AllUsersDesktop', 'Programs', 'AllUsersPrograms')]
    folders.append(Path(os.environ['APPDATA']) / 'Microsoft/Internet Explorer/Quick Launch/User Pinned/TaskBar')
    return list(dict.fromkeys(folders))


def refresh():
    ctypes.windll.shell32.SHChangeNotify(0x08000000, 0, None, None)


def startup(enabled):
    shell = win32com.client.Dispatch('WScript.Shell')
    path = Path(shell.SpecialFolders('Startup')) / 'MonoIcons.lnk'
    if not enabled:
        path.unlink(missing_ok=True)
        return
    link = shell.CreateShortcut(str(path))
    if getattr(sys, 'frozen', False):
        link.TargetPath = sys.executable
    else:
        pythonw = Path(sys.executable).with_name('pythonw.exe')
        link.TargetPath = str(pythonw if pythonw.exists() else Path(sys.executable))
        link.Arguments = '"' + str(Path(__file__).resolve().parents[1] / 'main.py') + '"'
    link.WorkingDirectory = str(Path(sys.executable).parent)
    link.Description = 'MonoIcons — monochrome shortcut icons'
    link.Save()


def icon_image(location, size=256):
    path, separator, index = location.rpartition(',')
    if not separator:
        path, index = location, '0'
    try:
        index = int(index)
    except ValueError:
        path, index = location, 0
    path = os.path.expandvars(path.strip().strip('"'))
    if path.lower().endswith(('.ico', '.png', '.bmp')) and index == 0:
        with Image.open(path) as image:
            return image.convert('RGBA').copy()
    extract = ctypes.windll.shell32.SHDefExtractIconW
    extract.argtypes = [wintypes.LPCWSTR, ctypes.c_int, wintypes.UINT,
                        ctypes.POINTER(wintypes.HICON), ctypes.POINTER(wintypes.HICON), wintypes.UINT]
    extract.restype = ctypes.c_long
    handle = wintypes.HICON()
    result = extract(path, index, 0, ctypes.byref(handle), None, size)
    if result < 0 or not handle.value:
        raise OSError(f'Cannot extract icon: {path} ({index})')
    try:
        def render(background):
            screen = win32gui.GetDC(0)
            dc = win32ui.CreateDCFromHandle(screen)
            memory = dc.CreateCompatibleDC()
            bitmap = win32ui.CreateBitmap()
            bitmap.CreateCompatibleBitmap(dc, size, size)
            previous = memory.SelectObject(bitmap)
            try:
                memory.FillSolidRect((0, 0, size, size), background)
                win32gui.DrawIconEx(memory.GetSafeHdc(), 0, 0, handle.value, size, size, 0, None, win32con.DI_NORMAL)
                return Image.frombuffer('RGB', (size, size), bitmap.GetBitmapBits(True), 'raw', 'BGRX', 0, 1).copy()
            finally:
                memory.SelectObject(previous)
                win32gui.DeleteObject(bitmap.GetHandle())
                memory.DeleteDC()
                dc.Detach()
                win32gui.ReleaseDC(0, screen)
        black, white = render(0), render(0xffffff)
        pixels = []
        for b, w in zip(black.getdata(), white.getdata()):
            alpha = 255 - max(w[i] - b[i] for i in range(3))
            pixels.append(tuple(min(255, round(v * 255 / alpha)) for v in b) + (alpha,) if alpha else (0, 0, 0, 0))
        image = Image.new('RGBA', (size, size))
        image.putdata(pixels)
        return image
    finally:
        win32gui.DestroyIcon(handle.value)


class Backend:
    def __init__(self):
        self.shell = win32com.client.Dispatch('WScript.Shell')

    def read(self, path):
        link = self.shell.CreateShortcut(path)
        return link.IconLocation, link.TargetPath

    def write(self, path, icon):
        link = self.shell.CreateShortcut(path)
        link.IconLocation = icon
        link.Save()

    def convert(self, source, destination):
        image = grayscale(icon_image(source))
        image.save(destination, format='ICO', sizes=[(16,16),(24,24),(32,32),(48,48),(64,64),(128,128),(256,256)])
