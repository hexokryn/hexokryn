"""Portable image conversion and crash-safe shortcut journal."""
import hashlib
import json
import os
from pathlib import Path

from PIL import Image, ImageOps


def grayscale(image):
    rgba = image.convert('RGBA')
    gray = ImageOps.grayscale(rgba).convert('RGBA')
    gray.putalpha(rgba.getchannel('A'))
    return gray


def atomic_json(path, value):
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    temporary = path.with_suffix('.tmp')
    with temporary.open('w', encoding='utf-8') as stream:
        json.dump(value, stream, ensure_ascii=False, indent=2)
        stream.flush()
        os.fsync(stream.fileno())
    os.replace(temporary, path)


class Engine:
    def __init__(self, directory, backend):
        self.directory = Path(directory)
        self.directory.mkdir(parents=True, exist_ok=True)
        self.path = self.directory / 'originals.json'
        self.records = json.loads(self.path.read_text('utf-8')) if self.path.exists() else {}
        self.backend = backend
        self.conflicts = 0

    def apply(self, shortcut):
        key = str(Path(shortcut).absolute())
        current, target = self.backend.read(key)
        old = self.records.get(key)
        if old:
            if target != old['target']:
                self.conflicts += 1
                return False
            if current == old['generated']:
                return False
            if current != old['original'] or target != old['target']:
                self.conflicts += 1
                return False
        source = current if current and current.rsplit(',', 1)[0].strip() else target
        digest = hashlib.sha256((key + '\0' + source).encode()).hexdigest()
        generated = str(self.directory / (digest + '.ico')) + ',0'
        self.backend.convert(source, generated.rsplit(',', 1)[0])
        self.records[key] = {'original': current, 'generated': generated, 'target': target}
        # Persist BEFORE editing the shortcut so interruption remains recoverable.
        atomic_json(self.path, self.records)
        self.backend.write(key, generated)
        return True

    def restore(self):
        restored = 0
        for key, record in list(self.records.items()):
            if not Path(key).exists():
                continue  # Keep recovery data for a temporarily disconnected location.
            current, target = self.backend.read(key)
            if target != record['target'] or current not in (record['generated'], record['original']):
                continue  # Never overwrite somebody else's subsequent changes.
            if current == record['generated']:
                self.backend.write(key, record['original'])
            del self.records[key]
            atomic_json(self.path, self.records)
            restored += 1
        return restored
