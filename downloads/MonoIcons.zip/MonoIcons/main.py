"""Run on Windows 11 with pythonw main.py, or build using build.cmd."""
import sys

if sys.platform != 'win32':
    raise SystemExit('MonoIcons requires Windows 10/11.')

import ctypes
import logging
from logging.handlers import RotatingFileHandler
import os
from pathlib import Path
import queue
import threading

import pythoncom
from PIL import Image, ImageDraw
import pystray

from monoicons.core import Engine, atomic_json
from monoicons.windows import Backend, refresh, roots, startup


def main():
    kernel = ctypes.windll.kernel32
    kernel.CreateMutexW.argtypes = [ctypes.c_void_p, ctypes.c_int, ctypes.c_wchar_p]
    kernel.CreateMutexW.restype = ctypes.c_void_p
    mutex = kernel.CreateMutexW(None, False, 'Local\\Hexokryn.MonoIcons')
    if not mutex:
        raise ctypes.WinError()
    if kernel.GetLastError() == 183:
        return
    directory = Path(os.environ['LOCALAPPDATA']) / 'MonoIcons'
    directory.mkdir(parents=True, exist_ok=True)
    log = logging.getLogger('monoicons')
    log.setLevel(logging.INFO)
    handler = RotatingFileHandler(directory / 'monoicons.log', maxBytes=1_000_000, backupCount=2, encoding='utf-8')
    log.addHandler(handler)
    config_path = directory / 'settings.json'
    import json
    try:
        config = json.loads(config_path.read_text('utf-8')) if config_path.exists() else {}
    except (ValueError, OSError):
        config = {'paused': True}
        log.exception('Cannot read settings; paused for safety')
    state = {'paused': config.get('paused', False), 'autostart': config.get('autostart', False), 'status': 'Запуск…'}
    commands = queue.Queue()
    drawing = Image.new('RGBA', (64,64))
    pen = ImageDraw.Draw(drawing)
    pen.rounded_rectangle((5,5,59,59), radius=13, fill='#181818', outline='white', width=3)
    pen.polygon([(17,45),(17,19),(24,19),(32,32),(40,19),(47,19),(47,45),(40,45),(40,31),(32,43),(24,31),(24,45)], fill='white')

    def send(command):
        return lambda icon, item: commands.put(command)

    def notify(text):
        state['status'] = text
        tray.title = 'MonoIcons — ' + text
        tray.update_menu()

    def persist():
        atomic_json(config_path, {k: state[k] for k in ('paused','autostart')})

    def worker():
        pythoncom.CoInitialize()
        try:
            engine = Engine(directory / 'icons', Backend())
            locations = roots()
            while True:
                try:
                    command = commands.get(timeout=30)
                except queue.Empty:
                    command = 'scan'
                if command == 'exit':
                    return
                try:
                    if command == 'toggle':
                        state['paused'] = not state['paused']
                        persist()
                    elif command == 'startup':
                        startup(not state['autostart'])
                        state['autostart'] = not state['autostart']
                        persist()
                    elif command == 'restore':
                        state['paused'] = True
                        persist()
                        count = engine.restore()
                        refresh()
                        notify(f'Восстановлено: {count}. Пауза.')
                        continue
                    if state['paused']:
                        notify('Пауза')
                        continue
                    changed = errors = 0
                    engine.conflicts = 0
                    for location in locations:
                        if not location.exists():
                            continue
                        for path in location.rglob('*'):
                            if path.suffix.lower() != '.lnk':
                                continue
                            try:
                                changed += engine.apply(path)
                            except Exception:
                                errors += 1
                                log.exception('Cannot update %s', path)
                    if changed:
                        refresh()
                    notify(f'ЧБ: {len(engine.records)} · ошибок: {errors} · пропущено: {engine.conflicts}')
                except Exception:
                    log.exception('Operation failed')
                    notify('Ошибка. Открой журнал.')
        except Exception:
            state['paused'] = True
            log.exception('Initialization failed')
            notify('Ошибка запуска. Открой журнал.')
        finally:
            pythoncom.CoUninitialize()

    def quit_app(icon, item):
        commands.put('exit')
        icon.stop()

    tray = pystray.Icon('MonoIcons', drawing, 'MonoIcons', menu=pystray.Menu(
        pystray.MenuItem(lambda item: state['status'], None, enabled=False),
        pystray.Menu.SEPARATOR,
        pystray.MenuItem('Проверить сейчас', send('scan')),
        pystray.MenuItem('Пауза', send('toggle'), checked=lambda item: state['paused']),
        pystray.MenuItem('Запускать с Windows', send('startup'), checked=lambda item: state['autostart']),
        pystray.MenuItem('Вернуть исходные значки', send('restore')),
        pystray.MenuItem('Открыть журнал', lambda icon, item: os.startfile(str(directory / 'monoicons.log'))),
        pystray.Menu.SEPARATOR,
        pystray.MenuItem('Выход', quit_app)))
    thread = threading.Thread(target=worker)

    def ready(icon):
        icon.visible = True
        thread.start()
        commands.put('scan')
    tray.run(setup=ready)
    if thread.is_alive():
        thread.join()
    kernel.CloseHandle.argtypes = [ctypes.c_void_p]
    kernel.CloseHandle(mutex)


if __name__ == '__main__':
    main()
