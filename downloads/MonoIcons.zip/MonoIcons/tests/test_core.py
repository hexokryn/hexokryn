import json
from pathlib import Path
import tempfile
import unittest
from PIL import Image
from monoicons.core import Engine, grayscale


class Backend:
    def __init__(self, shortcut):
        self.values = {str(shortcut): ('color.ico,0', 'app.exe')}
        self.fail = False
        self.writes = 0

    def read(self, key):
        return self.values[key]

    def convert(self, source, destination):
        self.source = source
        grayscale(Image.new('RGBA', (32,32), (250,20,10,123))).save(destination, format='ICO')

    def write(self, key, value):
        if self.fail:
            raise PermissionError('read-only')
        self.writes += 1
        self.values[key] = (value, self.values[key][1])


class Tests(unittest.TestCase):
    def setUp(self):
        self.temp = tempfile.TemporaryDirectory()
        self.addCleanup(self.temp.cleanup)
        self.root = Path(self.temp.name)
        self.shortcut = self.root / 'app.lnk'
        self.shortcut.touch()
        self.backend = Backend(self.shortcut)
        self.engine = Engine(self.root / 'icons', self.backend)

    def test_grayscale_keeps_alpha(self):
        image = Image.new('RGBA', (2,1))
        image.putdata([(255,0,0,123), (0,200,20,0)])
        result = grayscale(image)
        for r,g,b,a in result.getdata():
            self.assertEqual(r,g)
            self.assertEqual(g,b)
        self.assertEqual(list(result.getchannel('A').getdata()), [123,0])

    def test_round_trip_survives_restart(self):
        self.assertTrue(self.engine.apply(self.shortcut))
        location, _ = self.backend.read(str(self.shortcut))
        with Image.open(location.rsplit(',',1)[0]) as image:
            r,g,b,a = image.convert('RGBA').getpixel((0,0))
            self.assertEqual((r,g),(g,b))
            self.assertEqual(a,123)
        restarted = Engine(self.root / 'icons', self.backend)
        self.assertEqual(restarted.restore(), 1)
        self.assertEqual(self.backend.read(str(self.shortcut))[0], 'color.ico,0')
        self.assertEqual(json.loads(restarted.path.read_text()), {})

    def test_repeated_scan_is_idempotent(self):
        self.engine.apply(self.shortcut)
        self.assertFalse(self.engine.apply(self.shortcut))
        self.assertEqual(self.backend.writes,1)

    def test_user_edit_is_preserved(self):
        self.engine.apply(self.shortcut)
        self.backend.values[str(self.shortcut)] = ('custom.ico,0', 'app.exe')
        self.assertFalse(self.engine.apply(self.shortcut))
        self.assertEqual(self.engine.restore(),0)
        self.assertEqual(self.backend.read(str(self.shortcut))[0], 'custom.ico,0')

    def test_journal_exists_when_write_fails(self):
        self.backend.fail = True
        with self.assertRaises(PermissionError):
            self.engine.apply(self.shortcut)
        self.assertIn(str(self.shortcut),json.loads(self.engine.path.read_text()))
        self.backend.fail = False
        self.assertTrue(self.engine.apply(self.shortcut))
        self.assertEqual(self.engine.restore(),1)

    def test_deleted_shortcut_keeps_backup(self):
        self.engine.apply(self.shortcut)
        self.shortcut.unlink()
        self.assertEqual(self.engine.restore(),0)
        self.assertIn(str(self.shortcut),self.engine.records)

    def test_empty_icon_uses_target(self):
        self.backend.values[str(self.shortcut)] = (',0','app.exe')
        self.engine.apply(self.shortcut)
        self.assertEqual(self.backend.source,'app.exe')
        self.engine.restore()
        self.assertEqual(self.backend.read(str(self.shortcut))[0],',0')

    def test_changed_target_is_not_restored(self):
        self.engine.apply(self.shortcut)
        icon,_ = self.backend.read(str(self.shortcut))
        self.backend.values[str(self.shortcut)] = (icon,'other.exe')
        self.assertEqual(self.engine.restore(),0)
